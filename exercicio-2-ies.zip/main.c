/*. Fac¸a um programa que receba do usuario um arquivo texto e mostre na tela quantas ´
linhas esse arquivo possui.

BRUNA CAROLINA DA SILVA FEYH 
22/08/2023
*/
#include <stdio.h>
#include <errno.h>
#include <string.h>

#define MAX 10000

int getlinhas(char str[], int n){
    int i, c = 0;
    for(i=0; i<n; i++){
        if(str[i] == '\n') c++;
    }
    
    return c+1;
}

int lerarq(char *s, char str[]){
    FILE *f;
    f = fopen(s, "r");
    if(f == NULL) return errno;
    
    fscanf(f, "%[^EOF]", str);
 
    fclose(f);
    return 0;
}
int main()
{
    char ch[MAX];
    int erro, tam;
    
    erro = lerarq("arq.txt", ch);
    if(erro != 0) printf("erro de leitura: %d\n", erro);
    
    tam = strlen(ch);
    
    printf("Quantidade de linhas no arquivo: %d", getlinhas(ch, tam));
   
    return 0;
}